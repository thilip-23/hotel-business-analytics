# Hotel Review Sentiment

## 📊 Project Overview
Analyzed customer reviews from hotel websites using NLP to extract sentiment and correlated it with average pricing and occupancy trends.

## 🛠 Tools Used
Python (TextBlob/NLTK), Power BI, Excel

## 📁 Project Files
- `hotel_reviews.csv`
- `review_sentiment_dashboard.pbix`
- `review_sentiment_analysis.xlsx`

---

📌 This project is designed to simulate real-world data scenarios in the hospitality domain.
