# Hotel Pricing Analysis

## 📊 Project Overview
Scraped hotel pricing data from major booking websites, cleaned and analyzed data to uncover seasonal price trends and competitive positioning.

## 🛠 Tools Used
Python (BeautifulSoup), Excel, Power BI

## 📁 Project Files
- `hotel_pricing_data.csv`
- `hotel_pricing_dashboard.pbix`
- `hotel_pricing_analysis.xlsx`

---

📌 This project is designed to simulate real-world data scenarios in the hospitality domain.
