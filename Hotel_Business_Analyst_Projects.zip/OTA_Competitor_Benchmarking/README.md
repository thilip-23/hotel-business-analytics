# OTA Competitor Benchmarking

## 📊 Project Overview
Benchmarked hotel offerings and pricing across OTAs like Booking.com, Expedia, and MakeMyTrip through web scraping and built a competitor insight dashboard.

## 🛠 Tools Used
Python (Selenium), Excel, Power BI

## 📁 Project Files
- `ota_comparison_data.csv`
- `competitor_benchmark_dashboard.pbix`
- `ota_analysis.xlsx`

---

📌 This project is designed to simulate real-world data scenarios in the hospitality domain.
