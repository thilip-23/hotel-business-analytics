
# Hotel Business Analytics Project 🏨📊

## Overview
This project analyzes hotel pricing and occupancy data using web scraping, Python, Excel, and Power BI. It helps stakeholders identify pricing strategies, occupancy trends, and city-wise performance metrics.

## Features
- 🔍 Web scraping with Python (BeautifulSoup)
- 📈 Dashboarding using Power BI
- 🧹 Cleaned dataset in CSV
- 📊 City-level and rating-based insights

## Files Included
- `hotel_data_scraper.py` – Python script to scrape and clean hotel data
- `hotel_pricing_data.csv` – Clean dataset used in dashboard
- `hotel_dashboard.pbix` – Power BI dashboard file
- `README.md` – Project description and usage

## How to Use
1. Use the Python script to scrape updated hotel data.
2. Open the Power BI file (`hotel_dashboard.pbix`) to explore data visually.
3. Customize or extend for other business analysis use cases.

---

**Author:** YourName  
**Contact:** your.email@example.com  
**License:** MIT
