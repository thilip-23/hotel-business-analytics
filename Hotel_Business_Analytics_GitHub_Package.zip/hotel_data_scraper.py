
import requests
from bs4 import BeautifulSoup
import pandas as pd

# Example function: scrape hotel prices from a dummy HTML source (to be replaced with real endpoint)
def scrape_hotel_data(city_url):
    headers = {'User-Agent': 'Mozilla/5.0'}
    response = requests.get(city_url, headers=headers)
    soup = BeautifulSoup(response.text, 'html.parser')

    hotel_data = []
    listings = soup.find_all('div', class_='hotel-listing')  # Replace with actual class
    for hotel in listings:
        name = hotel.find('h2').text.strip()
        price = hotel.find('span', class_='price').text.strip().replace('$', '')
        rating = hotel.find('span', class_='stars').text.strip()
        occupancy = hotel.find('span', class_='occupancy').text.strip('%')
        hotel_data.append({
            'Hotel Name': name,
            'Price': float(price),
            'Rating': float(rating),
            'Occupancy (%)': float(occupancy)
        })

    return pd.DataFrame(hotel_data)

# Example usage (city URL is a placeholder)
# df = scrape_hotel_data("https://example.com/hotels-in-newyork")
# df.to_csv("hotel_pricing_data.csv", index=False)
